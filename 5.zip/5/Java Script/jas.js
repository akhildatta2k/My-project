burger = document.querySelector('.burger')
navbar = document.querySelector('.navbar')
rightnav = document.querySelector('.right-nav')
navlist = document.querySelector('.nav-list')
navlogo = document.querySelector('nav-logo')




burger.addEventListener('click', () => {
    navlist.classList.toggle('v-hidden-resp');
    navbar.classList.toggle('v-height-resp');
    rightnav.classList.toggle('v-hidden-resp');

})